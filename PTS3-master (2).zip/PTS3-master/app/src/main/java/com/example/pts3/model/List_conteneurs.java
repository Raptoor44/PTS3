package com.example.pts3.model;

import java.util.ArrayList;
import java.util.List;

public class List_conteneurs {

    public static List<Conteneurs> conteneursList = new ArrayList<Conteneurs>();

    public static List<Conteneurs> getConteneursList() {
        return conteneursList;
    }
}
